A Pen created at CodePen.io. You can find this one at https://codepen.io/mfrohberg/pen/KwPQWx.

 Attempting to recreate the mobile facebook app UI with Ionic